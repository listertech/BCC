angular.module('myApp').controller('AppCtrl', function($scope, $http) {
    $scope.showList = false;
    $scope.empty = false;  
    $scope.campaigns = [];
    $scope.first = true;

    // min date picker
    $scope.picker1 = {
        date: new Date(),
        datepickerOptions: {
            maxDate: null
        }
    };
    $scope.picker1.date.setDate($scope.picker1.date.getDate() - 7);

    // max date picker
    $scope.picker2 = {
        date: new Date(),
        datepickerOptions: {
            maxDate: null
        }
    };
    $scope.openCalendar = function(e, picker) {
        $scope[picker].open = true;
    };
    $scope.picker1.datepickerOptions.maxDate = new Date();
    $scope.picker2.datepickerOptions.maxDate = new Date();

    $scope.search = function() {
        console.log("in search" + $scope.email);

        if (angular.isUndefined($scope.email) || $scope.email == "") {
            BootstrapDialog.show({
                title: 'Error',
                message: 'Please enter a valid email ID'
            });

        } else {
        	$http.get("http://localhost:8080/bcc-service/bcc/myresource/getDynamoDBItem?mail="+$scope.email)
            .then(function(response) {
                    if (response.data.Filenames.length == 0) {
                    	//no campaigns found 
                    	$scope.showList = false;     
                    	$scope.empty = true;     
                    	$scope.first = false;          
                    }
                    else {
                    $scope.campaigns = [];					
                    console.log(JSON.stringify(response.data)+'--'+response.data.Filenames.length);
                    for (var i = 0; i < response.data.Filenames.length; i++) {
                    	var obj = {};
                    	obj.Filename = response.data.Filenames[i];
                    	obj.Subject = response.data.Subject[i];
                    	obj.SentDate = response.data.Date[i];
                    	obj.From = response.data.Filenames[i].toString().split("/")[0];
                    	//obj.CampaignType = response.data.CampaignType[i]; 
                    	//change
                    	obj.CampaignType = "Transactional";
                    	if(obj.CampaignType == "Promotional")
                    		$scope.type = "label label-primary";
                    	else
                    		$scope.type = "label label-success";
                    	var dateCompare = new Date(obj.SentDate);
                    	$scope.picker1.date.setHours(0,0,0,0);
                    	$scope.picker2.date.setHours(0,0,0,0);
                    	console.log(">"+dateCompare+">"+$scope.picker1.date+">"+$scope.picker2.date)
                    	if((dateCompare.getTime() <= $scope.picker2.date.getTime() && dateCompare.getTime() >= $scope.picker1.date.getTime()))      
                    	{
                    		$scope.campaigns.push(obj);
                    	}
                    	console.log("***"+JSON.stringify($scope.campaigns));
                    	}
                    	if($scope.campaigns.length > 0) {
							$scope.showList = true;
							$scope.empty = false;
							$scope.first = false;
                    	}
                    	else {
                    	//no campaigns found 
                    	$scope.showList = false;     
                    	$scope.empty = true; 
                    	$scope.first = false;  

                    	}
                     }
                },
                function(error) {
                   console.log("error");
                });
        }
    }
    $scope.getDetails = function(item) {
    	$scope.current = item;
        console.log("in" + $scope.email);
        $http.get("http://localhost:8080/bcc-service/bcc/myresource/getCampaignHtml?fileName="+item.Filename)
            .then(function(response) {
                    if (response.data.length == 0) {
                    //no body                       
                    }
                    else {
                    console.log(JSON.stringify(response.data));
                    angular.element( document.querySelector( '#modal-body' ) ).html(response.data.body);
                     }
                },
                function(error) {
                   console.log("error");
                });
    }
    $scope.getToday = function() {
        console.log("in1");
        $scope.dropdown = "Today";
    }
    $scope.getYday = function() {
        console.log("in2");
        $scope.dropdown = "Yesterday";
    }
    $scope.getWeek = function() {
        console.log("in3");
        $scope.dropdown = "Last 7 days";
    }
});