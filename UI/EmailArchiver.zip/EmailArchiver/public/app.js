'use strict';

angular.module('myApp', [
  'ui.router','ui.bootstrap','ui.bootstrap.datetimepicker'
]).config(function($stateProvider, $urlRouterProvider) {

    $urlRouterProvider.otherwise('/');
    
    $stateProvider.state('app', {
        url: '/',
        templateUrl: 'app/app.html',
        controller: 'AppCtrl'
    });
    
}).run(function () {

}); 