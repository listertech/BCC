import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.Date;
import org.quartz.Job;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;


import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.regions.Region;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.s3.AmazonS3;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.model.PutObjectResult;
import com.jcraft.jsch.*;

/**
 * Hello world!
 *
 */
public class Job1 implements Job
{

    public static void main(String[] args) {
         
    }
    public static AmazonS3 getS3obj()
    {
          AWSCredentials creds = new BasicAWSCredentials("AKIAIZXF4XUGIFLIPQGA", "URmKH0mu/6LSUIFvk2tMlOIHk5lNqvD6PU4bAoIm");  
          AmazonS3 s3= new AmazonS3Client(creds);          
          Region usWest2 = Region.getRegion(Regions.US_EAST_1);  
          s3.setRegion(usWest2);  return s3; 
          }
    public void execute(JobExecutionContext arg0) throws JobExecutionException {
        // TODO Auto-generated method stub
        System.out.println("Job2 --->>> Hello geeks! Time is " + new Date());
        String str_Host="52.9.146.109";     
     String str_Username="gfproduser";     
     int int_Port=22;     
     String str_FileDirectory="/home/gfproduser/Bcc";     
     String str_FileName="test.csv"; 
     JSch jsch = new JSch();
      StringBuilder obj_StringBuilder = new StringBuilder();
      try {
       String privateKey = "C://Users//sushmethaa.m//Downloads//key.ppk";
       jsch.addIdentity(privateKey);
       System.out.println("identity added ");
       com.jcraft.jsch.Session session = jsch.getSession(str_Username, str_Host, int_Port);
       System.out.println("session created.");
       java.util.Properties config = new java.util.Properties();
       config.put("StrictHostKeyChecking", "no");
       session.setConfig(config); // disabling StrictHostKeyChecking may help to make connection but makes it insecure// see http://stackoverflow.com/questions/30178936/jsch-sftp-security-with-session-setconfigstricthostkeychecking-no// // 
       java.util.Properties config1 = new java.util.Properties();
       // config.put("StrictHostKeyChecking", "no");
       // session.setConfig(config);
       session.connect();
       System.out.println("session connected.....");
       Channel channel = session.openChannel("sftp");
       channel.setInputStream(System.in);
       channel.setOutputStream(System.out);
       channel.connect();
       System.out.println("shell channel connected....");
       ChannelSftp c = (ChannelSftp) channel;
       c.cd(str_FileDirectory);
       System.out.println("Entered Location");
       InputStream obj_InputStream = c.get(str_FileName);
       System.out.println("Got File");
       char[] ch_Buffer = new char[0x10000];
       Reader obj_Reader = new InputStreamReader(obj_InputStream, "UTF-8");
       int int_Line = 0;
       do {
        int_Line = obj_Reader.read(ch_Buffer, 0, ch_Buffer.length);
        if (int_Line > 0) {
         obj_StringBuilder.append(ch_Buffer, 0, int_Line);
        }
       } while (int_Line >= 0);
       c.rm("/home/gfproduser/Bcc/test.csv");
       obj_Reader.close();
       obj_InputStream.close();
       c.exit();
       channel.disconnect();
       session.disconnect();
       System.out.println("done");
      } catch (Exception ex) {
       ex.printStackTrace();
      }
      System.out.println("reading file....." + obj_StringBuilder.toString());          
      try {
       AmazonS3 s3 = getS3obj();
       PutObjectResult pres = s3.putObject("sr-buk1", "FtpToAwsScheduler/" + (new Date()).toString(), obj_StringBuilder.toString());
       System.out.println(pres.getETag());
      
      } catch (Exception e) {
       e.printStackTrace();
      }
    } 

}